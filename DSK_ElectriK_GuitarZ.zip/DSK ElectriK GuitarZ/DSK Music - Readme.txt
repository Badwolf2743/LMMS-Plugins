DSK MUSIC
FREE VIRTUAL INSTRUMENTS AND SOUNDFONTS



- CONTACT INFO (suggest, send patches...):

dskmusic@gmail.com

http://dskmusic.wordpress.com
http://www.dskmusic.com


visit 4 upgrades and news ;)


----

DSK Music software is 100% free.
Donations are much appreciated. You may donate any amount to support DSK Music project by clicking the PayPal button in my site (you don�t need a PayPal account to donate) or directly to my paypal acount: dskmusic@live.com

THANKS!!!
